#!/bin/sh
java -cp "../luajava-1.0.jar" -Djava.library.path=.. org.keplerproject.luajava.Console awtTest.lua
